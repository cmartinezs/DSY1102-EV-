import kotlinx.coroutines.runBlocking

fun main() = runBlocking {
    val sistema = BikeCitySistema(capacidadSlots = 10)
    var continuar = true

    println("======================================")
    println("____BikeCity - Sistema de Arriendo____")
    println("======================================")


    // cerrar el programa, solo muestra error y vuelve a mostrar las opciones
    while (continuar) {
        mostrarMenu()
        when (readLine()?.trim()) {
            "1" -> opcionRegistrarEntrada(sistema)
            "2" -> opcionRegistrarSalida(sistema)
            "3" -> mostrarConsultas(sistema)
            "4" -> {
                sistema.reporteCierre()
                continuar = false
            }
            "0" -> continuar = false
            else -> println("Opcion invalida Intenta nuevamente.\n")
        }
    }

    println("Sesion de BikeCity  finalizada. Tenga buen dia :D")
}

private fun mostrarMenu() {
    println(
        """
        |Elige una opcion:
        |1- Registrar entrada de bicicleta
        |2- Registrar salida de bicicleta
        |3- Ver consultas de negocio
        |4- Ver reporte de cierre y salir
        |0- Salir sin reporte
        """.trimMargin()
    )
    print("> ")
}

/**menu- aqui se capturan errores y se muestran
**/
private suspend fun opcionRegistrarEntrada(sistema: BikeCitySistema) {
    try {
        println("\nTipo de bicicleta: 1) BiciCiudad  2) BiciMontana  3) BiciElectrica")
        print("Opcion: ")
        val tipo = readLine()?.trim()

        print("Codigo (formato AA00AA): ")
        val codigo = readLine()?.trim().orEmpty()

        print("Marca: ")
        val marca = readLine()?.trim().orEmpty()

        print("Modelo: ")
        val modelo = readLine()?.trim().orEmpty()

        println("Tipo de cliente:1) Turista  2) Abonado  3) Discapacitado")
        print("opcion: ")
        val tipoCliente = when (readLine()?.trim()) {
            "1" -> TipoCliente.TURISTA
            "2" -> TipoCliente.ABONADO
            "3" -> TipoCliente.DISCAPACITADO
            else -> throw IllegalArgumentException("Tipo de cliente invalido.")
        }

        val bicicleta = when (tipo) {
            "1" -> BiciCiudad(codigo, marca, modelo, tipoCliente)
            "2" -> BiciMontana(codigo, marca, modelo, tipoCliente)
            "3" -> {
                print("Es de larga autonomia? (s/n): ")
                val esLarga = readLine()?.trim()?.equals("s", ignoreCase = true) ?: false
                BiciElectrica(codigo, marca, modelo, tipoCliente, esLarga)
            }
            else -> throw IllegalArgumentException("Tipo de bicicleta invalido.")
        }

        sistema.registrarEntrada(bicicleta)
    } catch (e: CodigoInvalidoException) {
        println(" Error al registrar entrada: ${e.message}")
    } catch (e: SistemaSinCapacidadException) {
        println(" Error al registrar entrada: ${e.message}")
    } catch (e: IllegalArgumentException) {
        println(" Dato invalido: ${e.message}")
    }
    println()
}


private suspend fun opcionRegistrarSalida(sistema: BikeCitySistema) {
    try {
        print("\nCodigo de la biciclet que se devuelve: ")
        val codigo = readLine()?.trim().orEmpty()

        print("Minutos de uso: ")
        val minutos = readLine()?.trim()?.toIntOrNull()
            ?: throw IllegalArgumentException("Los minutos deben ser un número entero.")

        sistema.registrarSalida(codigo, minutos)
    } catch (e: BicicletaNoEncontradaException) {
        println(" Error al registrar salida: ${e.message}")
    } catch (e: TarifaInvalidaException) {
        println(" Error al registrar salida: ${e.message}")
    } catch (e: IllegalArgumentException) {
        println(" Dato invalido: ${e.message}")
    }
    println()
}


private fun mostrarConsultas(sistema: BikeCitySistema) {
    println("\n=== Consultas de negocio ===")
    println("Slots disponibles ahora: ${sistema.slotsDisponibles()}")
    println("Bicicletas de clientes abonados: ${sistema.bicicletasDeAbonados().map { it.codigo }}")
    println("Ingreso promedio por bicicleta: ${sistema.ingresoPromedioPorBicicleta()}")
    println("Códigos de bicicletas finalizadas: ${sistema.codigosBicicletasFinalizadas()}")
    println("Bicicleta con mastiempo de uso: ${sistema.bicicletaConMasTiempoUso()?.bicicleta?.codigo}")
    println()
}

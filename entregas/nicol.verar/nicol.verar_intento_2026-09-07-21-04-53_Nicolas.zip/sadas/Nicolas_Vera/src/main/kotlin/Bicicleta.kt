import java.time.LocalDateTime

/**
 tipos de clientes
 */
enum class TipoCliente {
    TURISTA,
    ABONADO,
    DISCAPACITADO
}

/**
 * clase base de toda bicicleta del sistema*/
open class Bicicleta(
    val codigo: String,
    val marca: String,
    val modelo: String,
    val tipoCliente: TipoCliente,
    val fechaIngreso: LocalDateTime = LocalDateTime.now()
) {

    /** calcula el costo base sin iva y antes del descuento por discapacidad segun el tiempo de uso en minutos.
     */
    open fun calcularCostoBase(minutosUso: Int): Double {

        return 0.0
    }

    /**
     * texto descriptivo para mostrar en consola
     *
     */
    open fun detalle(): String {
        return "$marca $modelo (codigo: $codigo, cliente: $tipoCliente)"
    }
}

/**
 * biciviudad tarifa base 800hr -20% si abonado.
 */
class BiciCiudad(
    codigo: String,
    marca: String,
    modelo: String,
    tipoCliente: TipoCliente
) : Bicicleta(codigo, marca, modelo, tipoCliente) {

    companion object {
        const val TARIFA_BASE_HORA = 800.0
    }

    override fun calcularCostoBase(minutosUso: Int): Double {
        val horas = minutosUso / 60.0
        var costo = TARIFA_BASE_HORA * horas
        if (tipoCliente == TipoCliente.ABONADO) {
            costo *= 0.80 // 20% de descuento
        }
        return costo
    }

    override fun detalle(): String = "[BiciCiudad] ${super.detalle()}"
}

/**
 * bicimontana: tarifa base 1.500hr Si uso es menor a 20 minutos cobro = $0
 * no importa el tipo de cliente.
 */
class BiciMontana(
    codigo: String,
    marca: String,
    modelo: String,
    tipoCliente: TipoCliente
) : Bicicleta(codigo, marca, modelo, tipoCliente) {

    companion object {
        const val TARIFA_BASE_HORA = 1500.0
        const val MINUTOS_MINIMOS_COBRO = 20
    }

    override fun calcularCostoBase(minutosUso: Int): Double {
        if (minutosUso < MINUTOS_MINIMOS_COBRO) {
            return 0.0
        }
        val horas = minutosUso / 60.0
        return TARIFA_BASE_HORA * horas
    }

    override fun detalle(): String = "[BiciMontana] ${super.detalle()}"
}

/**
 * bicielectrica: tarifa base 2.200hr larga autonomia recargo + 30%*/
class BiciElectrica(
    codigo: String,
    marca: String,
    modelo: String,
    tipoCliente: TipoCliente,
    val esLargaAutonomia: Boolean
) : Bicicleta(codigo, marca, modelo, tipoCliente) {

    companion object {
        const val TARIFA_BASE_HORA = 2200.0
        const val RECARGO_LARGA_AUTONOMIA = 0.30
    }

    override fun calcularCostoBase(minutosUso: Int): Double {
        val horas = minutosUso / 60.0
        var costo = TARIFA_BASE_HORA * horas
        if (esLargaAutonomia) {
            costo *= (1 + RECARGO_LARGA_AUTONOMIA)
        }
        return costo
    }

    override fun detalle(): String {
        val autonomia = if (esLargaAutonomia) "larga autonomia: si" else "larga autonomia: no"
        return "[BiciElectrica] ${super.detalle()}, $autonomia"
    }
}

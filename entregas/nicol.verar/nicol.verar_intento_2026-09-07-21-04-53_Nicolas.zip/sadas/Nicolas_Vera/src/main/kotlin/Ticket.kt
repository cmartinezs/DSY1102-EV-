/**creacion de ticket al pedir bicicleta
 *
 */

data class Ticket(
    val numero: Int,
    val bicicleta: Bicicleta,
    val minutosUso: Int,
    val montoPagado: Double
)

import kotlinx.coroutines.delay


class BikeCitySistema(private val capacidadSlots: Int = 10) {

    // crecion del formato de codigo
    private val formatoCodigo = Regex("^[A-Za-z]{2}[0-9]{2}[A-Za-z]{2}$")

    private val slots: List<Slot> = List(capacidadSlots) { i -> Slot(i + 1) }
    private val historial = mutableListOf<Ticket>()
    private var recaudacionTotal = 0.0
    private val recaudacionPorTipo = mutableMapOf<String, Double>()
    private var contadorTicket = 1

    fun codigoEsValido(codigo: String): Boolean = formatoCodigo.matches(codigo)


    //registro de entrada


    suspend fun registrarEntrada(bicicleta: Bicicleta) {
        if (!codigoEsValido(bicicleta.codigo)) {
            throw CodigoInvalidoException("Código de bicicleta inválido: ${bicicleta.codigo}")
        }

        val slotLibre = slots.firstOrNull { it.estado is Estado.Libre }
            ?: throw SistemaSinCapacidadException("No hay slots disponibles para registrar la entrada.")

        slotLibre.estado = Estado.EnProceso("registrando entrada")
        delay(3000) // simula la comunicación con el sensor físico

        slotLibre.estado = Estado.Arrendada(bicicleta)
        println("✔ Entrada registrada: ${bicicleta.detalle()} -> slot ${slotLibre.numero}")
    }



    /** registro de salida y cobro calculando el iva y si es disca
     */
    suspend fun registrarSalida(codigo: String, minutosUso: Int): Ticket {
        val slotOcupado = slots.firstOrNull { slot ->
            val estadoActual = slot.estado
            estadoActual is Estado.Arrendada && estadoActual.bicicleta.codigo == codigo
        } ?: throw BicicletaNoEncontradaException("No se encontró una bicicleta con código $codigo en el sistema.")

        val bicicleta = (slotOcupado.estado as Estado.Arrendada).bicicleta

        slotOcupado.estado = Estado.EnProceso("calculando tarifa")
        delay(6500) //espera para simulat sensor

        val costoBase = bicicleta.calcularCostoBase(minutosUso)
        val costoConIva = costoBase * 1.19
        val montoFinal = if (bicicleta.tipoCliente == TipoCliente.DISCAPACITADO) {
            costoConIva * 0.5
        } else {
            costoConIva
        }


        val esCasoMontanaBajoMinimo = bicicleta is BiciMontana && minutosUso < BiciMontana.MINUTOS_MINIMOS_COBRO
        if (montoFinal < 0 || (montoFinal == 0.0 && !esCasoMontanaBajoMinimo)) {
            throw TarifaInvalidaException("Se calcul una tarifa inválida ($montoFinal) para el código $codigo.")
        }

        val ticket = Ticket(contadorTicket++, bicicleta, minutosUso, montoFinal)
        historial.add(ticket)
        recaudacionTotal += montoFinal
        val tipoNombre = bicicleta.javaClass.simpleName ?: "Desconocido"
        recaudacionPorTipo[tipoNombre] = (recaudacionPorTipo[tipoNombre] ?: 0.0) + montoFinal

        slotOcupado.estado = Estado.Libre
        println(" Salida registrada: ticket #${ticket.numero} - ${bicicleta.codigo} - $$montoFinal")
        return ticket
    }

/**consultas de negoco*/

    fun slotsDisponibles(): Int = slots.count { it.estado is Estado.Libre }

    fun bicicletasDeAbonados(): List<Bicicleta> =
        historial.filter { it.bicicleta.tipoCliente == TipoCliente.ABONADO }.map { it.bicicleta }

    fun ingresoPromedioPorBicicleta(): Double =
        if (historial.isEmpty()) 0.0 else historial.sumOf { it.montoPagado } / historial.size

    fun codigosBicicletasFinalizadas(): List<String> = historial.map { it.bicicleta.codigo }

    fun bicicletaConMasTiempoUso(): Ticket? = historial.maxByOrNull { it.minutosUso }

    fun tipoConMasIngresos(): String? = recaudacionPorTipo.maxByOrNull { it.value }?.key

/**reporte para cierre de turno*/
    fun reporteCierre() {
        println("\n===== REPORTE DE CIERRE DE TURNO - BikeCity====")
        historial.forEach { ticket ->
            println(
                "Ticket #${ticket.numero} | ${ticket.bicicleta.javaClass.simpleName} | " +
                    "codigo: ${ticket.bicicleta.codigo} | tiempo: ${ticket.minutosUso} min | " +
                    "monto: $${"%.0f".format(ticket.montoPagado)}"
            )
        }
        println("--------------------------------------------------")
        println("total recaudado: $${"%.0f".format(recaudacionTotal)}")
        println("Bicicletas atendidas: ${historial.size}")
        println("Ingreso promedio: $${"%.0f".format(ingresoPromedioPorBicicleta())}")
        println("Tipo con más ingresos: ${tipoConMasIngresos() ?: "N/A"}")
        println("Slots disponibles al cierre: ${slotsDisponibles()}")
        println("==================================================\n")
    }
}

/**
 * estados posibles de un slot
 */
sealed class Estado {
    object Libre : Estado()
    data class Arrendada(val bicicleta: Bicicleta) : Estado()
    data class EnProceso(val motivo: String) : Estado()
    data class EnMantencion(val motivo: String) : Estado()
}


class Slot(val numero: Int) {
    var estado: Estado = Estado.Libre


    fun descripcionEstado(): String {
        return when (val e = estado) {
            is Estado.Libre -> "Libre"
            is Estado.Arrendada -> "Arrendada (bicicleta ${e.bicicleta.codigo})"
            is Estado.EnProceso -> "En proceso (${e.motivo})"
            is Estado.EnMantencion -> "En mantención (${e.motivo})"
        }
    }
}

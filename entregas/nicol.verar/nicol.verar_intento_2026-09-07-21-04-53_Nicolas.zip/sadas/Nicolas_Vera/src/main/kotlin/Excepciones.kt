
class CodigoInvalidoException(mensaje: String) : Exception(mensaje)
class TarifaInvalidaException(mensaje: String) : Exception(mensaje)
class BicicletaNoEncontradaException(mensaje: String) : Exception(mensaje)
class SistemaSinCapacidadException(mensaje: String) : Exception(mensaje)

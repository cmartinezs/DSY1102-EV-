plugins {
    kotlin("jvm") version "1.9.22"
    application
}

group = "cl.bikecity"
version = "1.0"

repositories {
    mavenCentral()
}

dependencies {
    // Dependencia de corrutinas requerida por R5 (registro asíncrono de entradas/salidas)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.7.3")
    testImplementation(kotlin("test"))
}

application {
    // Punto de entrada del programa
    mainClass.set("MainKt")
}

tasks.test {
    useJUnitPlatform()
}

kotlin {
    jvmToolchain(17)
}

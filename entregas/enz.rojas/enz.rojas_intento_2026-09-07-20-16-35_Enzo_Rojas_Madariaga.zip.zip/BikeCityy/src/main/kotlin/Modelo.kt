import java.time.LocalDateTime

enum class TipoCliente { TURISTA, ABONADO, DISCAPACITADO }

sealed class EstadoSlot {
    object Libre : EstadoSlot()
    data class Arrendada(val bicicleta: Bicicleta) : EstadoSlot()
    data class EnProceso(val motivo: String) : EstadoSlot()
    data class EnMantencion(val motivo: String) : EstadoSlot()
}

open class Bicicleta(
    val codigo: String,
    val marcaModelo: String,
    val fechaIngreso: LocalDateTime = LocalDateTime.now(),
    val tipoCliente: TipoCliente
) {
    init {
        val regex = Regex("^[A-Za-z]{2}\\d{2}[A-Za-z]{2}$")
        if (!regex.matches(codigo)) {
            throw IllegalArgumentException("Código inválido: '$codigo'. Formato requerido: 2 letras, 2 dígitos, 2 letras.")
        }
    }

    open fun calcularMontoBase(minutos: Long): Double {
        val horas = minutos / 60.0
        return horas * 800.0
    }

    fun calcularMontoTotal(minutos: Long): Double {
        val montoBase = calcularMontoBase(minutos)
        var subtotal = montoBase

        if (subtotal < 0) {
            throw IllegalStateException("El cálculo generó una tarifa negativa inválida.")
        }

        val conIva = subtotal * 1.19
        val total = if (tipoCliente == TipoCliente.DISCAPACITADO) conIva * 0.50 else conIva

        return total
    }
}

class BiciCiudad(codigo: String, marcaModelo: String, tipoCliente: TipoCliente)
    : Bicicleta(codigo, marcaModelo, LocalDateTime.now(), tipoCliente) {
    override fun calcularMontoBase(minutos: Long): Double {
        val horas = minutos / 60.0
        val tarifa = horas * 800.0
        return if (tipoCliente == TipoCliente.ABONADO) tarifa * 0.80 else tarifa
    }
}

class BiciMontana(codigo: String, marcaModelo: String, tipoCliente: TipoCliente)
    : Bicicleta(codigo, marcaModelo, LocalDateTime.now(), tipoCliente) {
    override fun calcularMontoBase(minutos: Long): Double {
        if (minutos < 20) return 0.0
        val horas = minutos / 60.0
        return horas * 1500.0
    }
}

class BiciElectrica(codigo: String, marcaModelo: String, tipoCliente: TipoCliente, val esLargaAutonomia: Boolean)
    : Bicicleta(codigo, marcaModelo, LocalDateTime.now(), tipoCliente) {
    override fun calcularMontoBase(minutos: Long): Double {
        val horas = minutos / 60.0
        var tarifa = horas * 2200.0
        if (esLargaAutonomia) tarifa *= 1.30
        return tarifa
    }
}

data class Ticket(
    val numeroTicket: Int,
    val codigoBici: String,
    val tipoBici: String,
    val tiempoMinutos: Long,
    val montoPagado: Double
)
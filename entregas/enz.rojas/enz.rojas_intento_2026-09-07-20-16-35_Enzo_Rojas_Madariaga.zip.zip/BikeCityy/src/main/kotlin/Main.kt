import kotlinx.coroutines.runBlocking

fun main() = runBlocking {
    val sistema = SistemaBikeCity()

    println("=== INICIO DE OPERACIÓN BIKE CITY ===")

    println("\n--- Prueba de Validaciones y Excepciones ---")
    try {
        val biciInvalida = BiciCiudad("123ABC", "Trek FX3", TipoCliente.ABONADO)
    } catch (e: IllegalArgumentException) {
        println("❌ Excepción capturada correctamente: ${e.message}")
    }

    println("\n--- Registrando Entradas ---")
    val bici1 = BiciCiudad("BC12CD", "Trek FX3", TipoCliente.ABONADO)
    val bici2 = BiciCiudad("BC99ZA", "Giant Escape", TipoCliente.TURISTA)
    val bici3 = BiciMontana("BM22TO", "Scott Aspect", TipoCliente.TURISTA)
    val bici4 = BiciElectrica("BE44RG", "Specialized Vado", TipoCliente.DISCAPACITADO, esLargaAutonomia = true)
    val bici5 = BiciElectrica("BE77RG", "Trek Allant", TipoCliente.TURISTA, esLargaAutonomia = false)

    sistema.registrarEntrada(bici1)
    sistema.registrarEntrada(bici2)
    sistema.registrarEntrada(bici3)
    sistema.registrarEntrada(bici4)
    sistema.registrarEntrada(bici5)

    println("\nSlots libres actuales: ${sistema.slotsDisponibles()}")

    println("\n--- Registrando Salidas ---")
    sistema.registrarSalida("BC12CD", 75)
    sistema.registrarSalida("BC99ZA", 180)
    sistema.registrarSalida("BM22TO", 18)
    sistema.registrarSalida("BE44RG", 120)
    sistema.registrarSalida("BE77RG", 45)

    sistema.registrarSalida("XX99XX", 30)

    sistema.mostrarReporteCierre()
}
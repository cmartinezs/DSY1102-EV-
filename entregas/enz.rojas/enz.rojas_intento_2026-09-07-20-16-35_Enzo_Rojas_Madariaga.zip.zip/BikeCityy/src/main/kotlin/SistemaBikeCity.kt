import kotlinx.coroutines.delay

class Slot(val numero: Int, var estado: EstadoSlot = EstadoSlot.Libre)

class SistemaBikeCity {
    val slots = List(10) { Slot(it + 1) }
    val historialTickets = mutableListOf<Ticket>()
    private var contadorTickets = 1

    suspend fun registrarEntrada(bici: Bicicleta) {
        val slotLibre = slots.firstOrNull { it.estado is EstadoSlot.Libre }

        if (slotLibre == null) {
            println("❌ ERROR: Sistema sin capacidad. No hay slots libres.")
            return
        }

        println("⏳ Sensor procesando entrada para bici ${bici.codigo} en Slot ${slotLibre.numero}...")
        slotLibre.estado = EstadoSlot.EnProceso("Registrando entrada")
        delay(3000)

        slotLibre.estado = EstadoSlot.Arrendada(bici)
        println("✅ Entrada confirmada: Bici ${bici.codigo} asignada al Slot ${slotLibre.numero}.")
    }

    suspend fun registrarSalida(codigoBici: String, minutosUso: Long) {
        val slot = slots.firstOrNull {
            val estado = it.estado
            estado is EstadoSlot.Arrendada && estado.bicicleta.codigo == codigoBici
        }

        if (slot == null) {
            println("❌ ERROR: Bicicleta '$codigoBici' no encontrada en los slots activos.")
            return
        }

        val bici = (slot.estado as EstadoSlot.Arrendada).bicicleta
        println("⏳ Procesando salida y calculando tarifa para bici $codigoBici...")
        slot.estado = EstadoSlot.EnProceso("Calculando tarifa")
        delay(6500)

        val totalPagar = bici.calcularMontoTotal(minutosUso)
        val ticket = Ticket(contadorTickets++, bici.codigo, bici::class.simpleName ?: "Bici", minutosUso, totalPagar)

        historialTickets.add(ticket)
        slot.estado = EstadoSlot.Libre

        println("🎫 TICKET EMITIDO #${ticket.numeroTicket} | Bici: ${ticket.codigoBici} | Minutos: $minutosUso | Total: $${String.format("%.2f", totalPagar)}")
    }

    fun slotsDisponibles(): Int = slots.count { it.estado is EstadoSlot.Libre }
    fun ingresoPromedio(): Double = if (historialTickets.isNotEmpty()) historialTickets.sumOf { it.montoPagado } / historialTickets.size else 0.0
    fun biciMasUso(): Ticket? = historialTickets.maxByOrNull { it.tiempoMinutos }

    fun mostrarReporteCierre() {
        println("\n==========================================")
        println("       REPORTE DE CIERRE DE TURNO        ")
        println("==========================================")

        historialTickets.forEach { t ->
            println("Ticket #${t.numeroTicket} | Tipo: ${t.tipoBici} | Código: ${t.codigoBici} | Tiempo: ${t.tiempoMinutos} min | Monto: $${String.format("%.2f", t.montoPagado)}")
        }

        val totalRecaudado = historialTickets.sumOf { it.montoPagado }
        val masUso = biciMasUso()

        println("------------------------------------------")
        println("Total Recaudado: $${String.format("%.2f", totalRecaudado)}")
        println("Bicicletas Atendidas: ${historialTickets.size}")
        println("Ingreso Promedio: $${String.format("%.2f", ingresoPromedio())}")
        println("Bicicleta con más uso: ${masUso?.codigoBici ?: "N/A"} (${masUso?.tiempoMinutos ?: 0} min)")
        println("Slots Disponibles al cierre: ${slotsDisponibles()}")
        println("==========================================\n")
    }
}
plugins {
    kotlin("jvm") version "2.3.10"
}

group = "org.example"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

dependencies {
    testImplementation(kotlin("test"))
}

kotlin {
    jvmToolchain(25)
}

tasks.test {
    useJUnitPlatform()
}

dependencies {
    // Permite simular los tiempos de espera de los sensores sin colgar el sys.
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.8.0")
}
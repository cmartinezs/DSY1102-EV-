class tarifaBase {
}
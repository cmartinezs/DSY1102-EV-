import kotlinx.coroutines.delay

class SistemaGymSmart {

    // Capacidad de 10 puestos fisicos
    val puestos: List<Puesto> = List(10) { Puesto(it + 1) }
    private val historial = mutableListOf<Ticket>()

    // Funcion suspendida para la entrada (espera 3 segundos)
    suspend fun registrarEntrada(equipo: Equipo) {
        try {

            // Validacion de formato: 2 letras, 2 numeros, 2 letras
            if (!equipo.codigo.matches(Regex("^[a-zA-Z]{2}\\d{2}[a-zA-Z]{2}$"))) {
                throw IllegalArgumentException("Codigo de equipo invalido: ${equipo.codigo}")
            }

            val puesto = puestos.firstOrNull { it.estado is EstadoPuesto.Libre }
                ?: throw IllegalStateException("Sistema sin capacidad. No hay puestos libres.")

            puesto.estado = EstadoPuesto.EnProceso("Registrando entrada en sensor")
            println("Sensor: Esperando ingreso de ${equipo.nombre}...")
            delay(3000) // Simulacion asíncrona

            puesto.estado = EstadoPuesto.EnUso(equipo)
            val extra = if (equipo is Funcional) " | Con entrenador: ${(equipo as Funcional).conEntrenador}" else ""
            println("INGRESO: ${equipo.nombre} asignado al puesto ${puesto.numero}$extra")

        } catch (e: Exception) {
            println("ERROR: ${e.message}") // se localiza el error y el programa no se detiene
        }
    }

    // Funcion suspendida para la salida (espera 6.5 segundos)
    suspend fun registrarSalida(codigo: String, minutos: Int) {
        try {
            val puesto = puestos.find { it.estado is EstadoPuesto.EnUso && (it.estado as EstadoPuesto.EnUso).equipo.codigo == codigo }
                ?: throw IllegalArgumentException("Equipo $codigo no encontrado en uso.")

            val equipo = (puesto.estado as EstadoPuesto.EnUso).equipo

            puesto.estado = EstadoPuesto.EnProceso("Calculando tarifa")
            println("Sensor: Procesando salida de $codigo...")
            delay(6500)

            // Logica de calculo estricta
            val tarifaBase = equipo.calcularTarifaBase(minutos)
            var totalConIva = tarifaBase * 1.19

            if (equipo.tipoUsuario == TipoUsuario.TerceraEdad) {
                totalConIva *= 0.5
            }

            if (totalConIva <= 0 && tarifaBase > 0) {
                throw IllegalArgumentException("Tarifa invalida (cero o negativa).")
            }

            // Guardar en historial y liberar el rack
            historial.add(Ticket(equipo, minutos, totalConIva))
            puesto.estado = EstadoPuesto.Libre
            println("TICKET: $codigo | Tiempo: $minutos min | Total pagado: $${totalConIva.toInt()}")

        } catch (e: Exception) {
            println("ERROR: ${e.message}")
        }
    }

    // Consultas de negocio usando funciones de orden superior (filter, sumOf, maxByOrNull)
    fun reporteCierre() {
        println("\n======= REPORTE DE CIERRE =======")
        historial.forEach {
            println("Ticket -> Tipo: ${it.equipo.javaClass.simpleName} | Código: ${it.equipo.codigo} | Uso: ${it.minutos} min | Monto: $${it.montoPagado.toInt()}")
        }

        val puestosLibres = puestos.count { it.estado is EstadoPuesto.Libre }
        val equiposSocio = historial.filter { it.equipo.tipoUsuario == TipoUsuario.Socio }
        val totalRecaudado = historial.sumOf { it.montoPagado }
        val ingresoPromedio = if (historial.isNotEmpty()) totalRecaudado / historial.size else 0.0
        val codigosFinalizados = historial.map { it.equipo.codigo }.joinToString(", ")
        val masTiempo = historial.maxByOrNull { it.minutos }?.equipo?.nombre ?: "Ninguno"

        println("\n--- Resumen ---")
        println("Puestos disponibles ahora: $puestosLibres")
        println("Equipos usados por Socios: ${equiposSocio.size}")
        println("Ingreso promedio por equipo: $${ingresoPromedio.toInt()}")
        println("Codigos finalizados hoy: [$codigosFinalizados]")
        println("Equipo con mas tiempo de uso: $masTiempo")
        println("TOTAL RECAUDADO: $${totalRecaudado.toInt()}")
    }
}
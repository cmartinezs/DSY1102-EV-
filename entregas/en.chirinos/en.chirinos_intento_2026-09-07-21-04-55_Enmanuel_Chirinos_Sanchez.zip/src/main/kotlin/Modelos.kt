import java.time.LocalDateTime

//Estados inquebrantables del puesto.
sealed class EstadoPuesto {
    object Libre : EstadoPuesto()
    data class EnUso(val equipo: Equipo) : EstadoPuesto()
    data class EnProceso(val motivo: String) : EstadoPuesto()
    data class EnMantencion(val motivo: String) : EstadoPuesto()
}

enum class TipoUsuario { Visitantes, Socio, TerceraEdad }

// Clase Padre: Define los datos que todas las maquinas comparten.
// Declaracion de Atributos de Equipo.

abstract class Equipo (
    val  codigo: String,
    val nombre: String,
    val tipoUsuario: TipoUsuario
) {
    // Hora exacta automatica.
    val fechaIngreso: LocalDateTime = LocalDateTime.now()
    abstract fun calcularTarifaBase(minutos: Int): Double
}

// Clases hijas: Heredan de equipo y aplican sus propias reglas mat.
class Cardio(
    codigo: String,
    nombre: String,
    tipoUsuario: TipoUsuario) : Equipo(codigo, nombre, tipoUsuario) {
    override fun calcularTarifaBase(minutos: Int): Double {
        var cobro = (1000.0 / 60) * minutos
        //20% descuento
        if (tipoUsuario == TipoUsuario.Socio) cobro*= 0.8
        return cobro
    }
}

class Fuerza(
    codigo: String,
    nombre: String,
    tipoUsuario: TipoUsuario) : Equipo(codigo, nombre, tipoUsuario) {
    override fun calcularTarifaBase(minutos: Int): Double {
        if (minutos <15) return 0.0 // Gratis si es menor a 15 min
        return (1500.0 / 60) * minutos
    }
}
// Estructuras fisicas e historial
class Puesto(
    val numero: Int,
    var estado: EstadoPuesto = EstadoPuesto.Libre)

data class Ticket(
    val equipo: Equipo,
    val minutos: Int,
    val montoPagado: Double)
// comprobante que se emite al finalizar una atencion
class Ticket(
    val numero: Int,
    val paciente: Paciente,
    val minutosUso: Int,
    val monto: Double
)

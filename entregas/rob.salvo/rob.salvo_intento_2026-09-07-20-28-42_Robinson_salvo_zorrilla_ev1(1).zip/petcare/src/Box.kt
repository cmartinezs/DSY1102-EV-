
class Box(val numero: Int) {
    var estado: String = "Libre"
    var pacienteActual: Paciente? = null
    var motivo: String = "" // se usa cuando estado es EnProceso o FueraDeServicio
}

// lógica del negocio: registrar entradas y salidas
// calcular tarifas, responder consultas y manejar errores sin detener
// el programa. Usa listas (ArrayList) y for.
class SistemaPetCare(val capacidad: Int = 10) {

    val boxes = ArrayList<Box>()
    val historial = ArrayList<Ticket>()
    var recaudacionTotal = 0.0
    var contadorTicket = 1

    init {
        // crean los boxes libres al iniciar el sistema.
        for (i in 1..capacidad) {
            boxes.add(Box(i))
        }
    }

    // solo se imprime el mensaje.
    // quien llama a esta función hace return después, así el programa sigue funcionando.
    fun mostrarError(mensaje: String) {
        println("Error: $mensaje")
    }

    // busca el primer box con estado Libre. si no encuentra ninguno, devuelve null.
    fun buscarBoxLibre(): Box? {
        for (box in boxes) {
            if (box.estado == "Libre") {
                return box
            }
        }
        return null
    }

    // busca el box que tiene al paciente.
    fun buscarBoxPorCodigo(codigo: String): Box? {
        for (box in boxes) {
            if (box.estado == "EnAtencion" && box.pacienteActual?.codigo == codigo) {
                return box
            }
        }
        return null
    }

     // registra el ingreso de un paciente. Thread.sleep(3000) simula que el

    fun registrarEntrada(paciente: Paciente) {
        if (!esCodigoValido(paciente.codigo)) {
            mostrarError("código de atención inválido: ${paciente.codigo}")
            return
        }

        val box = buscarBoxLibre()
        if (box == null) {
            mostrarError("no hay boxes libres, el sistema está lleno")
            return
        }

        box.estado = "EnProceso"
        box.motivo = "registrando entrada"


        box.estado = "EnAtencion"
        box.pacienteActual = paciente
        println("Box ${box.numero}: ingreso de ${paciente.nombre} (${paciente.codigo}) confirmado")
    }

    //registra la salida y cobra el monto.
    fun registrarSalida(codigo: String, minutosUso: Int) {
        val box = buscarBoxPorCodigo(codigo)
        if (box == null) {
            mostrarError("paciente no encontrado: $codigo")
            return
        }

        val paciente = box.pacienteActual!!
        box.estado = "EnProceso"
        box.motivo = "calculando tarifa"


        val monto = calcularMontoFinal(paciente, minutosUso)
        if (monto < 0.0) {
            mostrarError("resultado de tarifa inválido para $codigo")
            box.estado = "EnAtencion" // el paciente se queda en el box, no se libera
            return
        }

        val ticket = Ticket(contadorTicket, paciente, minutosUso, monto)
        contadorTicket = contadorTicket + 1
        historial.add(ticket)
        recaudacionTotal = recaudacionTotal + monto

        box.estado = "Libre"
        box.pacienteActual = null
        println("Ticket #${ticket.numero} | $codigo | $minutosUso min | \$${monto.toInt()}")
    }


    // costo según el tipo de paciente,  + iva 19%,
    //si es municipal, 50% de descuento sobre el monto que ya tiene iva.
    fun calcularMontoFinal(paciente: Paciente, minutos: Int): Double {
        var monto = paciente.calcularCostoBase(minutos)
        monto = monto * 1.19 // paso 2: IVA

        if (paciente.dueno == "Municipal") {
            monto = monto * 0.5 // descuento municipal
        }

        return monto
    }

    //consultas de negocio

    fun contarBoxesDisponibles(): Int {
        var contador = 0
        for (box in boxes) {
            if (box.estado == "Libre") {
                contador = contador + 1
            }
        }
        return contador
    }

    fun pacientesConvenio(): ArrayList<Ticket> {
        val lista = ArrayList<Ticket>()
        for (ticket in historial) {
            if (ticket.paciente.dueno == "Convenio") {
                lista.add(ticket)
            }
        }
        return lista
    }

    fun ingresoPromedio(): Double {
        if (historial.size == 0) {
            return 0.0
        }
        return recaudacionTotal / historial.size
    }

    fun codigosFinalizados(): ArrayList<String> {
        val lista = ArrayList<String>()
        for (ticket in historial) {
            lista.add(ticket.paciente.codigo)
        }
        return lista
    }

    // recorre el historial a mano guardando el ticket con más minutos hasta el momento.
    fun pacienteConMasTiempo(): Ticket? {
        if (historial.size == 0) {
            return null
        }
        var mayor = historial[0]
        for (ticket in historial) {
            if (ticket.minutosUso > mayor.minutosUso) {
                mayor = ticket
            }
        }
        return mayor
    }

    //muestra el resumen final del turno.
    fun reporteCierre() {
        println("\n===== REPORTE DE CIERRE - PetCare =====")

        for (ticket in historial) {
            println("Ticket #${ticket.numero} | ${ticket.paciente.tipo} | ${ticket.paciente.codigo} | ${ticket.minutosUso} min | \$${ticket.monto.toInt()}")
        }

        // Se suma por separado cuánto generó cada tipo de paciente,

        var totalCanino = 0.0
        var totalFelino = 0.0
        var totalExotico = 0.0

        for (ticket in historial) {
            if (ticket.paciente.tipo == "Canino") {
                totalCanino = totalCanino + ticket.monto
            }
            if (ticket.paciente.tipo == "Felino") {
                totalFelino = totalFelino + ticket.monto
            }
            if (ticket.paciente.tipo == "Exotico") {
                totalExotico = totalExotico + ticket.monto
            }
        }

        var tipoTop = "N/A"
        var mayorMonto = 0.0
        if (totalCanino > mayorMonto) {
            mayorMonto = totalCanino
            tipoTop = "Canino"
        }
        if (totalFelino > mayorMonto) {
            mayorMonto = totalFelino
            tipoTop = "Felino"
        }
        if (totalExotico > mayorMonto) {
            mayorMonto = totalExotico
            tipoTop = "Exotico"
        }

        println("----------------------------------------")
        println("Total recaudado: \$${recaudacionTotal.toInt()}")
        println("Pacientes atendidos: ${historial.size}")
        println("Ingreso promedio: \$${ingresoPromedio().toInt()}")
        println("Tipo con más ingresos: $tipoTop")
        println("Boxes disponibles: ${contarBoxesDisponibles()}")
    }
}

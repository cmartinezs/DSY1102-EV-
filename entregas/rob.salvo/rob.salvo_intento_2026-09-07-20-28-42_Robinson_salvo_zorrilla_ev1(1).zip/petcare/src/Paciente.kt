// Este archivo modela al paciente y calcula su costo

class Paciente(
    val codigo: String,
    val nombre: String,
    val especie: String,
    val tipo: String,        // canino, felino o exotico
    val dueno: String,       // particular, convenio o municipal
    val silvestre: Boolean = false // solo se usa si el tipo es exotico
) {
    // Calcula el costo antes de iva, según el tipo de paciente
    fun calcularCostoBase(minutos: Int): Double {
        val horas = minutos / 60.0

        if (tipo == "Canino") {
            var costo = 12000.0 * horas
            if (dueno == "Convenio") {
                costo = costo * 0.8 // 20% de descuento por convenio
            }
            return costo
        }

        if (tipo == "Felino") {
            // regla especial: menos de 20 minutos no se cobra, sin importar el dueño.
            if (minutos < 20) {
                return 0.0
            }
            return 9000.0 * horas
        }

        if (tipo == "Exotico") {
            var costo = 20000.0 * horas
            if (silvestre) {
                costo = costo * 1.3 // 30% de recargo si es silvestre
            }
            return costo
        }

        // si el tipo no coincide con ninguno de los tres, no se cobra nada.
        return 0.0
    }
}

// valida el formato del código de atención: 2 letras + 2 números + 2 letras

fun esCodigoValido(codigo: String): Boolean {
    if (codigo.length != 6) {
        return false
    }
    val letra1Ok = codigo[0].isLetter()
    val letra2Ok = codigo[1].isLetter()
    val numero1Ok = codigo[2].isDigit()
    val numero2Ok = codigo[3].isDigit()
    val letra3Ok = codigo[4].isLetter()
    val letra4Ok = codigo[5].isLetter()

    return letra1Ok && letra2Ok && numero1Ok && numero2Ok && letra3Ok && letra4Ok
}

// punto de entrada del programa.
fun main() {
    val sistema = SistemaPetCare(10)

    // entrada
    sistema.registrarEntrada(Paciente("CA12CD", "Max", "Golden Retriever", "Canino", "Convenio"))
    sistema.registrarEntrada(Paciente("CA99ZA", "Luna", "Labrador", "Canino", "Particular"))
    sistema.registrarEntrada(Paciente("FE22TO", "Misi", "Siamés", "Felino", "Particular"))
    sistema.registrarEntrada(Paciente("EX44RG", "Loro", "Amazónico", "Exotico", "Municipal", true))
    sistema.registrarEntrada(Paciente("EX77RG", "Iguana", "Verde", "Exotico", "Particular", false))

    // prueba de error: código con formato inválido
    sistema.registrarEntrada(Paciente("123ABC", "Error", "Test", "Canino", "Particular"))

    // salidas
    sistema.registrarSalida("CA12CD", 75)
    sistema.registrarSalida("CA99ZA", 180)
    sistema.registrarSalida("FE22TO", 18)
    sistema.registrarSalida("EX44RG", 120)
    sistema.registrarSalida("EX77RG", 45)

    // prueba de error: código que no existe en el sistema
    sistema.registrarSalida("ZZ00ZZ", 30)

    //  consultas de negocio
    println("\nBoxes disponibles: ${sistema.contarBoxesDisponibles()}")
    println("Cantidad de pacientes convenio: ${sistema.pacientesConvenio().size}")
    println("Ingreso promedio: ${sistema.ingresoPromedio()}")
    println("Códigos finalizados: ${sistema.codigosFinalizados()}")
    println("Paciente con más tiempo: ${sistema.pacienteConMasTiempo()?.paciente?.codigo}")

    sistema.reporteCierre()
}

rootProject.name = "petcare"

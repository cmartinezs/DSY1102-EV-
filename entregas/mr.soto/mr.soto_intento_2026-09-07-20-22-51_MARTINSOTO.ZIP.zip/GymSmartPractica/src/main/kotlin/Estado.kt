sealed class EstadoEquipo {

    object Disponible : EstadoEquipo()

    object EnUso : EstadoEquipo()

    object FueraDeServicio : EstadoEquipo()
}

fun mostrarDato(nombre: String?) {

    if (nombre != null) {
        println("Nombre: $nombre")
    } else {
        println("No se ingresó un nombre")
    }
}

fun obtenerTarifa(tipo: String): Double {

    return when (tipo) {
        "basico" -> 100.0
        "premium" -> 200.0
        "vip" -> 300.0
        else -> 0.0
    }
}
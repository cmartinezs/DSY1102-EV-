import kotlinx.coroutines.runBlocking

fun main() = runBlocking {

    println("GymSmart Practica")


    val nombre = "Juan"
    var edad = 20
    val precio = 1500.0
    val activo = true

    println("\n--- Variables ---")
    println("Nombre: $nombre")
    println("Edad: $edad")
    println("Precio: $precio")
    println("Activo: $activo")

    // If / else
    val minutos = 12

    println("\n--- Condicional ---")

    if (minutos < 15) {
        println("Uso gratuito")
    } else {
        println("Se debe cobrar")
    }


    val tipoUsuario = "socio"

    println("\n--- Tipo de usuario ---")

    when (tipoUsuario) {
        "visitante" -> println("Usuario visitante")
        "socio" -> println("Usuario socio")
        "tercera_edad" -> println("Usuario tercera edad")
        else -> println("Usuario desconocido")
    }


    val bicicleta = EquipoCardio("Bicicleta", 1500.0)
    val maquina = EquipoFuerza("Máquina de pesas", 2500.0)

    val equipos = listOf(bicicleta, maquina)

    println("\n--- Equipos ---")

    equipos.forEach {
        it.mostrarInformacion()
        println()
    }


    val equiposCaros = equipos.filter {
        it.precio > 2000
    }

    println("--- Equipos caros ---")

    equiposCaros.forEach {
        println(it.nombre)
    }


    val nombres = equipos.map {
        it.nombre
    }

    println("--- Nombres ---")
    println(nombres)


    val valorTotalEquipos = equipos.sumOf {
        it.precio
    }

    println("--- Valor total ---")
    println(valorTotalEquipos)


    println("\n--- Polimorfismo ---")

    for (equipo in equipos) {
        equipo.mostrarInformacion()
    }


    println("\n--- Usuarios ---")

    val usuario1 = Usuario("Juan", "socio")
    val usuario2 = Usuario("Pedro", "visitante")
    val usuario3 = Usuario("Ana", "socio")

    val usuarios = listOf(usuario1, usuario2, usuario3)

    usuarios.forEach {
        mostrarTipoUsuario(it)
    }

    mostrarSocios(usuarios)


    println("\n--- Dato opcional ---")

    mostrarDato("Carlos")
    mostrarDato(null)


    println("\n--- Tarifas ---")

    val tipo = "premium"
    val tarifa = obtenerTarifa(tipo)

    println("Tipo: $tipo")
    println("Tarifa: $tarifa")


    println("\n--- Cobro ---")

    val tipoCobro = "premium"
    val minutosCobro = 5

    val tarifaActual = obtenerTarifa(tipoCobro)
    val cobroFinal = calcularCobro(
        minutosCobro,
        tarifaActual
    )

    println("Tipo: $tipoCobro")
    println("Minutos: $minutosCobro")
    println("Tarifa: $tarifaActual")
    println("Cobro final: $cobroFinal")


    println("\n--- Estado del equipo ---")

    val estado = EstadoEquipo.Disponible

    when (estado) {
        EstadoEquipo.Disponible ->
            println("El equipo está disponible")

        EstadoEquipo.EnUso ->
            println("El equipo está en uso")

        EstadoEquipo.FueraDeServicio ->
            println("El equipo está fuera de servicio")
    }


    println("\n--- Validación ---")

    validarNumero("25")
    validarNumero("abc")


    println("\n--- Proceso con coroutine ---")

    simularProceso()
}
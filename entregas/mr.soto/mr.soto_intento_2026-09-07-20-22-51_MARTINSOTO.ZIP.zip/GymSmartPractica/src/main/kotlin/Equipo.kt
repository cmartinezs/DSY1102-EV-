open class Equipo(
    val nombre: String,
    val precio: Double
) {

    open fun mostrarInformacion() {
        println("Equipo: $nombre")
        println("Precio: $precio")
    }
}

class EquipoCardio(
    nombre: String,
    precio: Double
) : Equipo(nombre, precio) {

    override fun mostrarInformacion() {
        println("Tipo: Cardio")
        println("Equipo: $nombre")
        println("Precio: $precio")
    }
}

class EquipoFuerza(
    nombre: String,
    precio: Double
) : Equipo(nombre, precio) {

    override fun mostrarInformacion() {
        println("Tipo: Fuerza")
        println("Equipo: $nombre")
        println("Precio: $precio")
    }
}
fun validarNumero(texto: String) {

    try {
        val numero = texto.toInt()
        println("Número ingresado: $numero")

    } catch (e: NumberFormatException) {
        println("Error: debes ingresar un número")
    }
}

fun calcularTotal(precio: Double, cantidad: Int): Double {
    return precio * cantidad
}

fun calcularCobro(minutos: Int, precioPorMinuto: Double): Double {

    if (minutos <= 0) {
        return 0.0
    }

    return minutos * precioPorMinuto

}



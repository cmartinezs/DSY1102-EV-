data class Usuario(
    val nombre: String,
    val tipo: String
)

fun mostrarTipoUsuario(usuario: Usuario) {

    when (usuario.tipo) {
        "socio" -> println("${usuario.nombre} es socio")
        "visitante" -> println("${usuario.nombre} es visitante")
        "tercera_edad" -> println("${usuario.nombre} es tercera edad")
        else -> println("Tipo de usuario no válido")
    }
}

fun mostrarSocios(usuarios: List<Usuario>) {

    val socios = usuarios.filter {
        it.tipo == "socio"
    }

    println("Socios registrados:")

    socios.forEach {
        println(it.nombre)
    }
}
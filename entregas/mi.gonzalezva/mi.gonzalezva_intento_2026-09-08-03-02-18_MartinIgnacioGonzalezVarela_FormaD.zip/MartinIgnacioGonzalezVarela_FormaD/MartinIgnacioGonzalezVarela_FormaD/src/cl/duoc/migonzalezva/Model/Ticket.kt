package cl.duoc.migonzalezva.Model

data class Ticket(
    val numeroTicket: Int,
    val bicicleta: Bicicleta,
    val minutosUso: Int,
    val montoPagado: Double
)
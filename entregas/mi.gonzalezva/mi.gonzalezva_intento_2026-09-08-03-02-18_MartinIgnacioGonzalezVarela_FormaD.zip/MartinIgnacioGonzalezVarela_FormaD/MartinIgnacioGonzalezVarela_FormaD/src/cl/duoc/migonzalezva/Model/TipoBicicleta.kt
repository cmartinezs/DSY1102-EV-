package cl.duoc.migonzalezva.Model

enum class TipoBicicleta {
    CIUDAD,
    MONTANA,
    ELECTRICA
}
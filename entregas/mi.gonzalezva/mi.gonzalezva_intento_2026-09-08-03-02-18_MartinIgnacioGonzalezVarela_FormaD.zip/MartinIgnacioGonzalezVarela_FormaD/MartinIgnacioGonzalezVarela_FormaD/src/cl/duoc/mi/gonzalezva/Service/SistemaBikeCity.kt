package cl.duoc.migonzalezva.service

import cl.duoc.migonzalezva.exception.*
import cl.duoc.migonzalezva.model.*
import kotlinx.coroutines.delay

class SistemaBikeCity(totalSlots: Int = 10) {
    val slots = List(totalSlots) { i -> Slot(i + 1) }
    val historial = mutableListOf<Ticket>()

    var numTicket = 1
    var totalRecaudado = 0.0

    suspend fun registrarEntrada(bici: Bicicleta) {
        val slotLibre = slots.firstOrNull { it.estado is EstadoSlot.Libre }
            ?: throw SistemaSinCapacidadException("No hay espacio libre")

        slotLibre.estado = EstadoSlot.EnProceso("Entrando ${bici.codigo}")
        println("Esperando sensor entrada (3s)...")
        delay(3000)

        slotLibre.estado = EstadoSlot.Arrendada(bici)
        println("Bici ${bici.codigo} ingresada en Slot #${slotLibre.numero}\n")
    }

    suspend fun registrarSalida(codigoBici: String, minutos: Int): Ticket {
        val slotBici = slots.firstOrNull {
            val est = it.estado
            est is EstadoSlot.Arrendada && est.bicicleta.codigo == codigoBici
        } ?: throw BicicletaNoEncontradaException("Bici $codigoBici no existe")

        val bici = (slotBici.estado as EstadoSlot.Arrendada).bicicleta

        slotBici.estado = EstadoSlot.EnProceso("Saliendo $codigoBici")
        println("Procesando cobro en sensor (6.5s)...")
        delay(6500)

        val total = bici.calcularMontoTotal(minutos)
        val ticket = Ticket(numTicket++, bici, minutos, total)

        historial.add(ticket)
        totalRecaudado += total

        slotBici.estado = EstadoSlot.Libre
        println("Salida lista para $codigoBici. Slot #${slotBici.numero} liberado.")

        return ticket
    }

    fun slotsDisponibles() = slots.count { it.estado is EstadoSlot.Libre }

    fun obtenerBicisAbonados() = historial
        .map { it.bicicleta }
        .filter { it.tipoCliente == TipoCliente.ABONADO }
        .distinctBy { it.codigo }

    fun obtenerPromedio() = if (historial.isEmpty()) 0.0 else totalRecaudado / historial.size

    fun obtenerCodigosFinalizados() = historial.map { it.bicicleta.codigo }

    fun generarReporteCierre() {
        println("\n--- REPORTE DE CIERRE ---")
        for (t in historial) {
            println("Ticket #${t.numeroTicket} | Bici: ${t.bicicleta.codigo} | Min: ${t.minutosUso} | Total: $${t.montoPagado}")
        }
        println("-------------------------")
        println("Total Recaudado  : $$totalRecaudado")
        println("Bicis Atendidas  : ${historial.size}")
        println("Promedio Ingreso : $${obtenerPromedio()}")
        println("Slots Libres     : ${slotsDisponibles()}")
        println("-------------------------\n")
    }
}
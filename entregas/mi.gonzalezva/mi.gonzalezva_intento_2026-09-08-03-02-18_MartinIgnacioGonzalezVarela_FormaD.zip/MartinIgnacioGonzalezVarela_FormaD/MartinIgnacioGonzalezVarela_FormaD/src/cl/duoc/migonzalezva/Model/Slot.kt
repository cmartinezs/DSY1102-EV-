package cl.duoc.migonzalezva.Model

import cl.duoc.migonzalezva.model.EstadosSlot

data class Slot(
    val numero: Int,
    var estado: EstadosSlot = EstadosSlot.Libre
)
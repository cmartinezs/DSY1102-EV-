package cl.duoc.migonzalezva.Model

enum class TipoCliente {
    TURISTA,
    ABONADO,
    DISCAPACITADO
}
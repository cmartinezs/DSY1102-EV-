package cl.duoc.migonzalezva.Model

import cl.duoc.migonzalezva.exception.CodigoInvalidoException
import cl.duoc.migonzalezva.exception.TarifaInvalidaException
import java.time.LocalDateTime
import kotlin.math.ceil

abstract class Bicicleta(
    val codigo: String,
    val marcaModelo: String,
    val tipoCliente: TipoCliente,
    val fechaIngreso: LocalDateTime = LocalDateTime.now()
) {
    init {
        val regex = Regex("^[A-Z]{2}\\d{2}[A-Z]{2}$")
        if (!regex.matches(codigo)) {
            throw CodigoInvalidoException("El código '$codigo' no cumple con el formato requerido.")
        }
    }

    abstract val tarifaBaseHora: Double

    abstract fun calcularCostoBase(minutosUso: Int): Double

    fun calcularMontoTotal(minutosUso: Int): Double {
        val costoBase = calcularCostoBase(minutosUso)

        if (costoBase == 0.0 && this is BiciMontana && minutosUso < 20) {
            return 0.0
        }

        if (costoBase <= 0.0) {
            throw TarifaInvalidaException("El cálculo de tarifa generó un monto inválido: $$costoBase")
        }

        val montoConIVA = costoBase * 1.19

        return if (tipoCliente == TipoCliente.DISCAPACITADO) {
            montoConIVA * 0.50
        } else {
            montoConIVA
        }
    }
}

class BiciCiudad(
    codigo: String,
    marcaModelo: String,
    tipoCliente: TipoCliente
) : Bicicleta(codigo, marcaModelo, tipoCliente) {
    override val tarifaBaseHora = 800.0

    override fun calcularCostoBase(minutosUso: Int): Double {
        val horasCalculadas = ceil(minutosUso / 60.0)
        val horasAfectas = if (tipoCliente == TipoCliente.ABONADO) {
            horasCalculadas * 0.80
        } else {
            horasCalculadas
        }
        return horasAfectas * tarifaBaseHora
    }
}

class BiciMontana(
    codigo: String,
    marcaModelo: String,
    tipoCliente: TipoCliente
) : Bicicleta(codigo, marcaModelo, tipoCliente) {
    override val tarifaBaseHora = 1500.0

    override fun calcularCostoBase(minutosUso: Int): Double {
        if (minutosUso < 20) return 0.0
        val horasCalculadas = ceil(minutosUso / 60.0)
        return horasCalculadas * tarifaBaseHora
    }
}

class BiciElectrica(
    codigo: String,
    marcaModelo: String,
    tipoCliente: TipoCliente,
    val esLargaAutonomia: Boolean
) : Bicicleta(codigo, marcaModelo, tipoCliente) {
    override val tarifaBaseHora = 2200.0

    override fun calcularCostoBase(minutosUso: Int): Double {
        val horasCalculadas = ceil(minutosUso / 60.0)
        val recargo = if (esLargaAutonomia) 1.30 else 1.00
        return horasCalculadas * tarifaBaseHora * recargo
    }
}
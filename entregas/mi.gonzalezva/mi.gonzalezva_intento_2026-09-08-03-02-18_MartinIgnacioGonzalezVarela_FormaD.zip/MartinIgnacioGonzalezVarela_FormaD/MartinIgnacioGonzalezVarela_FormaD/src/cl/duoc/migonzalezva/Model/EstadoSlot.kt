package cl.duoc.migonzalezva.model

import cl.duoc.migonzalezva.Model.Bicicleta

sealed class EstadosSlot {
    object Libre : EstadosSlot() {
        override fun toString() = "Libre"
    }
    data class Arrendada(val bicicleta: Bicicleta) : EstadosSlot() {
        override fun toString() = "Arrendada (Bici: ${bicicleta.codigo})"
    }
    data class EnProceso(val motivo: String) : EstadosSlot() {
        override fun toString() = "En Proceso ($motivo)"
    }
    data class EnMantencion(val motivo: String) : EstadosSlot() {
        override fun toString() = "En Mantención ($motivo)"
    }
}
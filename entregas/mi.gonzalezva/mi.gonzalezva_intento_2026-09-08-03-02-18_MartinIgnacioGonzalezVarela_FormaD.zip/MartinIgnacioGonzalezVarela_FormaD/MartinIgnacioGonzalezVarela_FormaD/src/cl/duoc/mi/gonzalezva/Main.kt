package cl.duoc.migonzalezva

import cl.duoc.migonzalezva.Model.*
import cl.duoc.migonzalezva.exception.*
import cl.duoc.migonzalezva.main

fun main() {
    val SistemaBikeCity = (5)

    println("=== SISTEMA BIKE CITY EN MARCHA ===\n")

    try {
        val bici1 = BiciCiudad("BC12CD", "Trek FX", TipoCliente.TURISTA)
        val bici2 = BiciMontana("BM34EF", "Giant ATX", TipoCliente.ABONADO)
        val bici3 = BiciElectrica("BE56GH", "Specialized Turbo", TipoCliente.DISCAPACITADO, true)

        println("--- Bicis creadas con éxito ---")
        println("Bici 1: ${bici1.marcaModelo} (${bici1.codigo})")
        println("Bici 2: ${bici2.marcaModelo} (${bici2.codigo})")
        println("Bici 3: ${bici3.marcaModelo} (${bici3.codigo})")

    } catch (e: BikeCityException) {
        println("Error del sistema: ${e.message}")
    } catch (e: Exception) {
        println("Error inesperado: ${e.message}")
    }
}
package cl.duoc.migonzalezva.exception

open class BikeCityException(msg: String) : Exception(msg)

class CodigoInvalidoException(msg: String) : BikeCityException(msg)
class TarifaInvalidaException(msg: String) : BikeCityException(msg)
class BicicletaNoEncontradaException(msg: String) : BikeCityException(msg)
class SistemaSinCapacidadException(msg: String) : BikeCityException(msg)
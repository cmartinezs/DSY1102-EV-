package model

import java.time.LocalDateTime

sealed class Paciente(
    val codigoAtencion: String,
    val nombre: String,
    val especie: String,
    val tipoDueno: TipoDueno,
    val fechaIngreso: LocalDateTime = LocalDateTime.now()
) {
    abstract val tarifaBaseHora: Double
    abstract val tipoDescripcion: String

    abstract fun calcularSubtotal(minutos: Long): Double

    fun calcularTotal(minutos: Long): Double {
        val subtotal = calcularSubtotal(minutos)
        if (subtotal == 0.0) return 0.0

        val conIva = subtotal * 1.19
        return if (tipoDueno == TipoDueno.MUNICIPAL) {
            conIva * 0.50
        } else {
            conIva
        }
    }

    companion object {
        private val REGEX_CODIGO = Regex("^[A-Za-z]{2}[0-9]{2}[A-Za-z]{2}$")

        fun esCodigoValido(codigo: String): Boolean = REGEX_CODIGO.matches(codigo)
    }
}

class Canino(
    codigoAtencion: String,
    nombre: String,
    especie: String,
    tipoDueno: TipoDueno
) : Paciente(codigoAtencion, nombre, especie, tipoDueno) {
    override val tarifaBaseHora: Double = 12000.0
    override val tipoDescripcion: String = "Canino"

    override fun calcularSubtotal(minutos: Long): Double {
        val horas = minutos / 60.0
        val base = horas * tarifaBaseHora
        return if (tipoDueno == TipoDueno.CONVENIO) {
            base * 0.80
        } else {
            base
        }
    }
}

class Felino(
    codigoAtencion: String,
    nombre: String,
    especie: String,
    tipoDueno: TipoDueno
) : Paciente(codigoAtencion, nombre, especie, tipoDueno) {
    override val tarifaBaseHora: Double = 9000.0
    override val tipoDescripcion: String = "Felino"

    override fun calcularSubtotal(minutos: Long): Double {
        if (minutos < 20) return 0.0
        val horas = minutos / 60.0
        return horas * tarifaBaseHora
    }
}

class Exotico(
    codigoAtencion: String,
    nombre: String,
    especie: String,
    tipoDueno: TipoDueno,
    val esSilvestre: Boolean
) : Paciente(codigoAtencion, nombre, especie, tipoDueno) {
    override val tarifaBaseHora: Double = 20000.0
    override val tipoDescripcion: String = "Exótico"

    override fun calcularSubtotal(minutos: Long): Double {
        val horas = minutos / 60.0
        val base = horas * tarifaBaseHora
        return if (esSilvestre) {
            base * 1.30
        } else {
            base
        }
    }
}
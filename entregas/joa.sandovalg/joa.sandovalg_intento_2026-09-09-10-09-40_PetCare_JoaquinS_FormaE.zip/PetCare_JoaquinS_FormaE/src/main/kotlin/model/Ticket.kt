package model

data class Ticket(
    val numeroTicket: Int,
    val paciente: Paciente,
    val minutosAtendidos: Long,
    val montoPagado: Double
)
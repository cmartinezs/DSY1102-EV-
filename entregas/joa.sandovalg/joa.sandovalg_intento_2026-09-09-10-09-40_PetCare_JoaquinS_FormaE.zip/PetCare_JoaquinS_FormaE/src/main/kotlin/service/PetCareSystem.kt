package service

import kotlinx.coroutines.delay
import model.*

class PetCareSystem {
    val nombreSistema: String = "PetCare"
    private val boxes: MutableList<Box> = MutableList(10) { index -> Box(numero = index + 1) }
    private val historialTickets: MutableList<Ticket> = mutableListOf()
    private var contadorTickets: Int = 1

    fun obtenerBoxesDisponibles(): Int {
        return boxes.count { it.estado is EstadoBox.Libre }
    }

    fun obtenerPacientesConvenio(): List<Paciente> {
        return historialTickets.map { it.paciente }.filter { it.tipoDueno == TipoDueno.CONVENIO }
    }

    fun obtenerIngresoPromedio(): Double {
        if (historialTickets.isEmpty()) return 0.0
        return historialTickets.sumOf { it.montoPagado } / historialTickets.size
    }

    fun obtenerCodigosFinalizados(): List<String> {
        return historialTickets.map { it.paciente.codigoAtencion }
    }

    fun obtenerPacienteMayorTiempo(): Ticket? {
        return historialTickets.maxByOrNull { it.minutosAtendidos }
    }

    fun totalRecaudadoPorTipo(tipo: String): Double {
        return historialTickets
            .filter { it.paciente.tipoDescripcion.equals(tipo, ignoreCase = true) }
            .sumOf { it.montoPagado }
    }

    suspend fun registrarEntrada(paciente: Paciente): Boolean {
        println("\n>>> [OPERACIÓN ENTRADA] Solicitando ingreso para paciente ${paciente.nombre} (${paciente.codigoAtencion})")

        if (!Paciente.esCodigoValido(paciente.codigoAtencion)) {
            println("[ERROR DE DATOS] Código de atención inválido: '${paciente.codigoAtencion}'. Formato requerido: 2 letras, 2 dígitos, 2 letras.")
            return false
        }

        val boxLibre = boxes.firstOrNull { it.estado is EstadoBox.Libre }
        if (boxLibre == null) {
            println("[ERROR DE SISTEMA] No hay boxes disponibles en este momento. Capacidad completa.")
            return false
        }

        boxLibre.estado = EstadoBox.EnProceso("Registrando entrada en sensor")
        println("Box #${boxLibre.numero}: Conectando con sensor físico (espera 3s)...")
        delay(3000)

        boxLibre.estado = EstadoBox.EnAtencion(paciente)
        println("[ÉXITO] Paciente '${paciente.nombre}' asignado correctamente al Box #${boxLibre.numero}.")
        return true
    }

    suspend fun registrarSalida(codigoAtencion: String, minutosAtendidos: Long): Ticket? {
        println("\n<<< [OPERACIÓN SALIDA] Solicitando salida para código: $codigoAtencion")

        val boxAsignado = boxes.firstOrNull {
            val estado = it.estado
            estado is EstadoBox.EnAtencion && estado.paciente.codigoAtencion.equals(codigoAtencion, ignoreCase = true)
        }

        if (boxAsignado == null) {
            println("[ERROR DE DATOS] Paciente con código '$codigoAtencion' no encontrado en ningún box activo.")
            return null
        }

        val paciente = (boxAsignado.estado as EstadoBox.EnAtencion).paciente

        boxAsignado.estado = EstadoBox.EnProceso("Calculando tarifa y emitiendo ticket")
        println("Box #${boxAsignado.numero}: Calculando tarifa de salida (espera 6.5s)...")
        delay(6500)

        val total = paciente.calcularTotal(minutosAtendidos)

        if (total <= 0.0 && !(paciente is Felino && minutosAtendidos < 20)) {
            println("[ERROR DE DATOS] Tarifa calculada inválida ($$total) para el paciente $codigoAtencion.")
            boxAsignado.estado = EstadoBox.Libre
            return null
        }

        val ticket = Ticket(
            numeroTicket = contadorTickets++,
            paciente = paciente,
            minutosAtendidos = minutosAtendidos,
            montoPagado = total
        )

        historialTickets.add(ticket)
        boxAsignado.estado = EstadoBox.Libre

        println("[TICKET #${ticket.numeroTicket} EMITIDO]")
        println("  Paciente : ${paciente.nombre} (${paciente.tipoDescripcion})")
        println("  Código   : ${paciente.codigoAtencion}")
        println("  Tiempo   : ${minutosAtendidos} min")
        println("  Total    : $${String.format("%.0f", ticket.montoPagado)} (Box #${boxAsignado.numero} liberado)")

        return ticket
    }

    fun mostrarReporteCierre() {
        println("\n=======================================================")
        println("           REPORTE DE CIERRE DE TURNO - PETCARE        ")
        println("=======================================================")
        if (historialTickets.isEmpty()) {
            println("No se atendieron pacientes durante este turno.")
        } else {
            println(String.format("%-8s | %-10s | %-8s | %-10s | %-10s", "TICKET", "TIPO", "CÓDIGO", "TIEMPO", "MONTO"))
            println("-------------------------------------------------------")
            for (t in historialTickets) {
                println(
                    String.format(
                        "%-8d | %-10s | %-8s | %-7d min | $%-10.0f",
                        t.numeroTicket,
                        t.paciente.tipoDescripcion,
                        t.paciente.codigoAtencion,
                        t.minutosAtendidos,
                        t.montoPagado
                    )
                )
            }
        }
        println("-------------------------------------------------------")

        val totalRecaudado = historialTickets.sumOf { it.montoPagado }
        val cantidad = historialTickets.size
        val promedio = obtenerIngresoPromedio()
        val boxesLibres = obtenerBoxesDisponibles()

        val tipoTop = listOf("Canino", "Felino", "Exótico")
            .maxByOrNull { totalRecaudadoPorTipo(it) } ?: "N/A"

        println("Total recaudado turno     : $${String.format("%.0f", totalRecaudado)}")
        println("Recaudación Caninos       : $${String.format("%.0f", totalRecaudadoPorTipo("Canino"))}")
        println("Recaudación Felinos       : $${String.format("%.0f", totalRecaudadoPorTipo("Felino"))}")
        println("Recaudación Exóticos      : $${String.format("%.0f", totalRecaudadoPorTipo("Exótico"))}")
        println("Cantidad de pacientes     : $cantidad")
        println("Ingreso promedio/paciente : $${String.format("%.0f", promedio)}")
        println("Tipo con mayor ingreso    : $tipoTop")
        println("Boxes disponibles al cierre: $boxesLibres de 10")
        println("=======================================================\n")
    }
}
import kotlinx.coroutines.runBlocking
import model.*
import service.PetCareSystem

fun main() = runBlocking {
    val petCare = PetCareSystem()
    println("==================================================")
    println("      INICIANDO SISTEMA ${petCare.nombreSistema}   ")
    println("==================================================")

    // Datos de prueba sugeridos
    val p1 = Canino("CA12CD", "Max", "Golden Retriever", TipoDueno.CONVENIO)
    val p2 = Canino("CA99ZA", "Luna", "Labrador", TipoDueno.PARTICULAR)
    val p3 = Felino("FE22TO", "Misi", "Siamés", TipoDueno.PARTICULAR)
    val p4 = Exotico("EX44RG", "Loro", "Amazónico", TipoDueno.MUNICIPAL, esSilvestre = true)
    val p5 = Exotico("EX77RG", "Iguana", "Verde", TipoDueno.PARTICULAR, esSilvestre = false)

    // 1. Registro de entradas
    petCare.registrarEntrada(p1)
    petCare.registrarEntrada(p2)
    petCare.registrarEntrada(p3)
    petCare.registrarEntrada(p4)
    petCare.registrarEntrada(p5)

    // 2. Pruebas de errores (R6)
    println("\n--- PRUEBA DE CASOS DE ERROR (R6) ---")
    val pacienteInvalido = Canino("123ABC", "Toby", "Poodle", TipoDueno.PARTICULAR)
    petCare.registrarEntrada(pacienteInvalido)
    petCare.registrarSalida("XX99XX", 30)

    // 3. Registro de salidas con demoras asíncronas (R5)
    println("\n--- REGISTRO DE SALIDAS (R5) ---")
    petCare.registrarSalida("CA12CD", 75)
    petCare.registrarSalida("CA99ZA", 180)
    petCare.registrarSalida("FE22TO", 18)
    petCare.registrarSalida("EX44RG", 120)
    petCare.registrarSalida("EX77RG", 45)

    // 4. Consultas de negocio (R4)
    println("\n--- CONSULTAS DE NEGOCIO (R4) ---")
    println("1. Boxes disponibles ahora: ${petCare.obtenerBoxesDisponibles()}")
    println("2. Pacientes con convenio atendidos: ${petCare.obtenerPacientesConvenio().map { it.nombre }}")
    println("3. Ingreso promedio por paciente: $${String.format("%.0f", petCare.obtenerIngresoPromedio())}")
    println("4. Códigos finalizados: ${petCare.obtenerCodigosFinalizados()}")
    val mayor = petCare.obtenerPacienteMayorTiempo()
    println("5. Paciente con más tiempo de atención: ${mayor?.paciente?.nombre} (${mayor?.minutosAtendidos} min)")

    // 5. Cierre de turno
    petCare.mostrarReporteCierre()
}
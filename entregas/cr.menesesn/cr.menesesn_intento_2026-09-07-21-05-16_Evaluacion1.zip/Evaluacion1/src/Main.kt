//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {
    val nombre: String = "Cristopher"
    val edad: Int = 36
    val carrera: String = "Ingenieria en informatica"
    val promedio: Double = 7.0
    //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
    // to see how IntelliJ IDEA suggests fixing it.
    println("Mi nombre es: $nombre\nMi edad es: $edad\nMi carrera es: $carrera\nMi promedio es: $promedio")


}